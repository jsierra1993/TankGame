/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package tankgame;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.file.Paths;
import javax.swing.*;
import javax.sound.sampled.*;
/**
 *
 * @author jsierra
 */
public class Sound {
    URL url;
    private Clip clip;
    boolean loop;
    String path = System.getProperty("user.dir");
    private String soundFile; 
    private AudioInputStream soundStream; 
    
    Sound(String name, boolean loop) throws MalformedURLException, LineUnavailableException, UnsupportedAudioFileException, IOException{
        this.soundFile = name; 
        soundStream = AudioSystem.getAudioInputStream(Sound.class.getResource(name));
        clip = AudioSystem.getClip();
        this.loop = loop;

        clip.open(soundStream);
        SwingUtilities.invokeLater(new Runnable() {

          @Override
          public void run() {
           //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
          }
        });
    
    }

    public void play(){
        // loop clip playback
        
        if(loop){
            clip.loop(Clip.LOOP_CONTINUOUSLY);
        
        // play clip once
        }else{
            clip.setFramePosition(clip.getFrameLength()); // so that clip won't play twice intially
            clip.loop(1);
        }
        
    }
    
    public void flush(){    
        clip.flush();
    }
    
}
