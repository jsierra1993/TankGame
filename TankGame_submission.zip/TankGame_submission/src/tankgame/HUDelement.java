/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package tankgame;

import java.awt.Image;
import java.awt.image.ImageObserver;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
/**
 *
 * @author Kash, jsierra
 */
public class HUDelement extends TankWorld{
    
    Image[] element;
    int x, y, numFrames;
    String path = System.getProperty("user.dir");
    int frameCount = 0;

    private final TankWorld outer;

 
    HUDelement(String name, int numFrames, int x, int y, final TankWorld outer) throws IOException {
        this.x = x;
        this.y = y;
        this.numFrames = numFrames;
        path = name;
        this.outer = outer;
        element = new Image[numFrames];
        
       try{ 
        if (numFrames == 1) {
            
            element[0] = ImageIO.read(TankWorld.class.getResource( path + ".png"));
        
        } else {
            for (int i = 0; i < numFrames; i++) {
                //System.out.println( path + i + ".png");
                element[i] = ImageIO.read(TankWorld.class.getResource(path + i + ".png"));
            }
        }
       } catch(IOException e){
           e.printStackTrace();
       }

    }

    public void draw(ImageObserver obs, int x, int y) {
     
     
        outer.g2.drawImage(this.element[frameCount], x, y, obs);
    }


    public void update() {
        if (!(frameCount == numFrames - 1)) {
            frameCount++;
        }

    }

    public void reverse() {
        if (frameCount != 0) {
            frameCount--;
        }
    }
}
