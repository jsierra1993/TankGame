/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package tankgame;

import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
/**
 *
 * @author jsierra
 */
public class KeyControl extends KeyAdapter {
    private final TankWorld outer;
    GameEvents gameEvents; 
     
    public KeyControl( TankWorld outer) {
        this.outer = outer;
    }
    public void keyPressed(KeyEvent e) {
        outer.gameEvents.setValue(e);
    }
    
}
