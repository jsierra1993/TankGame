/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package tankgame;

import java.awt.AWTException;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.event.KeyEvent;
import java.awt.event.WindowAdapter;
import java.awt.geom.AffineTransform;
import java.awt.image.BufferedImage;
import java.awt.image.ImageObserver;
import java.io.BufferedReader;
import java.io.*;
import javax.imageio.ImageIO;
import java.io.FileReader;
import java.io.IOException;
import java.net.MalformedURLException;
import java.util.ArrayList;
import java.util.Observable;
import java.util.Observer;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import javax.swing.JApplet;
import javax.swing.JFrame;
import java.util.ListIterator;



/**
 *
 * @author kevin, jsierra
 */
public class TankWorld extends JApplet implements Runnable {
    
    private Thread thread; 
    private BufferedImage bimg1, bimg2;
 
    public static final TankWorld game = new TankWorld();
    Wall[][] layout = new Wall[28][50]; 

    Random generator = new Random(1234567);
    Rectangle box;
    int sizeX, sizeY, x, y, width, height;
    int move = 0, speed = 1;
    int score1 = 0;
    int score2 = 0;
    int fireCounter1, fireCounter2, fireCounter3;
    Tank m1, m2; 
  
    
    Image player1, player2, shell, background, bullet; 
    Image miniMap, leftScreen, rightScreen, powerUp;
    GameEvents gameEvents; 
    Graphics2D g2; 
    Bullet fire; 
   
    ArrayList<Bullet> clip = new <Bullet>ArrayList();
    
   // boolean gameOver, gameWon, gameFinished; 
    ImageObserver observer; 
    Explosion explode1, explode2;
    Sound backgroundMusic, boom1, boom2, gameOver, turret;
  
    Image wall1, wall2; 
    
    HUDelement healthBar1, healthBar2, healthLabel1, healthLabel2, score_1,
            score_2, scoreLabel1, scoreLabel2, game_over;

  
    int w = 1280, h = 758; // fixed size window game 

    public void init() {       
         
         setFocusable(true);
         setBackground(Color.white);
         
        try{
             
              bullet = ImageIO.read(TankWorld.class.getResource("Shell.png"));
              background = ImageIO.read(TankWorld.class.getResource("Background.bmp"));
              player1 = ImageIO.read(TankWorld.class.getResource("tank1.png"));
              player2 = ImageIO.read(TankWorld.class.getResource("tank2.png"));
              wall1 = ImageIO.read(TankWorld.class.getResource("Wall2.gif"));
              wall2 = ImageIO.read(TankWorld.class.getResource("Wall1.gif"));
              powerUp = ImageIO.read(TankWorld.class.getResource("Shield1.gif"));
             
              healthBar1 = new HUDelement("health", 5, 75, 820, this); 
              healthBar2 = new HUDelement("health", 5, 1450, 820, this); 
              game_over = new HUDelement("gameOverLabel", 1, 745, 10, this);
              healthLabel1 = new HUDelement("Player1Label", 1, 745, 15, this);
              healthLabel2 = new HUDelement("Player2Label", 1, 745, 15,this);
              scoreLabel2 = new HUDelement("scoreLabel", 1, 745, 15,this);
              scoreLabel1 = new HUDelement("scoreLabel", 1, 745, 15,this);
     
        
        String layoutStream;
      
   
        m1 = new Tank(player1, 350, 200, 10, 90);
        m2 = new Tank(player2, 700, 400, 10, 270);
        
        m1.health = 125; 
        m2.health = 125; 
       
       try{
           backgroundMusic = new Sound("Music.mid", true);
           backgroundMusic.play();
           boom1 = new Sound("Explosion1.wav", false);
           boom2 = new Sound("Explosion_large.wav", false);
           gameOver = new Sound("Gameover.wav", false);
           turret = new Sound("turret.wav", false);
           
       }catch(MalformedURLException | LineUnavailableException | UnsupportedAudioFileException ex){
            Logger.getLogger(TankWorld.class.getName()).log(Level.SEVERE, null, ex);
       }
            
            
            gameEvents = new GameEvents();
            gameEvents.addObserver(m1);
            gameEvents.addObserver(m2);
            
            KeyControl key = new KeyControl(this);
            addKeyListener(key);
            
        } catch(IOException e) {
            System.out.println("Resources not found");
        }
        System.out.println("Game Started");
    }
    
   public class Bullet {
       Image img;
       int x, bx;
       int y, by;
       int width;
       int height;
       int power;
       double angle;
       Rectangle box;
       boolean show;
       String shootStyle;
       private String owner;
       
       Bullet(Image img, int x, int y, int bx, int by, double angle){
           this.img = img;
           this.x = x;
           this.y = y;
           this.bx = bx;
           this.by = by;
           this.angle = angle;
           power = 5;
           height = img.getHeight(null);
           width = img.getWidth(null);
           show = true; 
       }
       
       public void draw(ImageObserver obs){
           if(show){
               AffineTransform old = g2.getTransform();
               g2.rotate(Math.toRadians(this.angle), this.x
                       + (this.width/2), this.y + (this.height /2));
               g2.drawImage(this.img, this.x, this.y, obs);
               g2.setTransform(old);
           }
       }
       
       public void update(int i) throws IOException {
           if(this.show){
               this.x += this.bx;
               this.y -= this.by;
           } else if(!show){
               this.x = this.bx;
               this.y = this.by;
//               boom1.flush();
  //             boom1.play();
               clip.remove(i);
           }
           
           if(this.y <= -20 || this.y > 940 || this.x < -20 || this.x > 1280){
               show = false;
               clip.remove(i);
               clip.trimToSize();
           }
           
            if (this.collision(m1.x, m1.y, m1.width, m1.height)
                    && "m2".equals(this.getOwnedBy())
                    && this.show == true && this != null) {
                gameEvents.setValue("m1_collision");
                score2 += 50;
                explode1 = new Explosion("explosion1_", 6, this.x, this.y, TankWorld.this);
               
                show = false;
                int j = clip.indexOf(this);
                clip.remove(i);
                clip.trimToSize();

            }
             if (this.collision(m2.x, m2.y, m2.width, m2.height)
                    && "m1".equals(this.getOwnedBy())
                    && this.show == true && this != null) {
                gameEvents.setValue("m2_collision");
                score1 += 50;
                explode1 = new Explosion("explosion1_", 6, this.x, this.y, TankWorld.this);
                
                show = false;
                int j = clip.indexOf(this);
                clip.remove(i);
                clip.trimToSize();

            } else {
                 
            }    
       }
       
        public boolean collision(int x, int y, int w, int h) {
            box = new Rectangle(this.x, this.y, this.width, this.height);
            Rectangle otherBBox = new Rectangle(x, y, w, h);
            return this.box.intersects(otherBBox);
        }
        public String getOwnedBy() {
            return owner;
        }
        public void setOwnedBy(String tankID) {
            owner = tankID;
        }
        
   }
    
    public class Tank implements Observer {

        Image img;
        int x, y, speed, width, height;
        double angle;

        protected int health = 100;
        Rectangle bbox;
        boolean boom = false;

        Tank(Image img, int x, int y, int speed, double angle) {
            this.img = img;
            this.x = x;
            this.y = y;
            this.speed = speed;
            width = img.getWidth(null);
            height = img.getHeight(null);
            boom = false;
            this.angle = angle;
        }

        public void draw(ImageObserver obs) {
            
            AffineTransform old = g2.getTransform();
            g2.rotate(Math.toRadians(this.angle), this.x + (this.width / 2), 
                    this.y + (this.height / 2));
            g2.drawImage(this.img, this.x, this.y, obs);
            g2.setTransform(old);
        }

       
        public boolean collision(int x, int y, int w, int h) {
            bbox = new Rectangle(this.x, this.y, this.width, this.height);
            Rectangle otherBBox = new Rectangle(x, y, w, h);
            return this.bbox.intersects(otherBBox);
        }

   
        public void update(Observable obj, Object arg) {
           
            double rotation = Math.toRadians(15);
            GameEvents ge = (GameEvents) arg;
          
            if (ge.type == 1) {
                KeyEvent e = (KeyEvent) ge.event;
                switch (e.getKeyCode()) {

                    case KeyEvent.VK_LEFT:
                        if (this.equals(m2)) {
                            m2.angle -= 15;
                        }
                        break;
                    case KeyEvent.VK_RIGHT:
                        if (this.equals(m2)) {
                            m2.angle += 15;
                        }
                        break;
                    case KeyEvent.VK_UP:
                        m2.y -= speed * Math.cos(Math.toRadians(m2.angle));
                        m2.x += speed * Math.sin(Math.toRadians(m2.angle));
                        break;
                    case KeyEvent.VK_DOWN:
                        m2.y += speed * Math.cos(Math.toRadians(m2.angle));
                        m2.x -= speed * Math.sin(Math.toRadians(m2.angle));
                        break;
                    case KeyEvent.VK_A:
                        if (this.equals(m1)) {
                            m1.angle -= 15;
                        }
                        break;
                    case KeyEvent.VK_D:
                        if (this.equals(m1)) {
                            m1.angle += 15;
                        }
                        break;
                    case KeyEvent.VK_W:
                        m1.y -= speed * Math.cos(Math.toRadians(m1.angle));
                        m1.x += speed * Math.sin(Math.toRadians(m1.angle));
                        break;
                    case KeyEvent.VK_S:
                        m1.y += speed * Math.cos(Math.toRadians(m1.angle));
                        m1.x -= speed * Math.sin(Math.toRadians(m1.angle));
                        break;
                    case KeyEvent.VK_ESCAPE:
                        System.exit(0);
                    case KeyEvent.VK_R:
                        m1.x -= 5;
                        m1.speed = 5;
                        break;
                    default:
                        if(e.getKeyChar() == ' ' && this.equals(m1)){
                            fire = new Bullet(bullet, m1.x + (m1.width/2), y + (height/2),
                                    (int)(m1.speed * Math.sin(Math.toRadians(m1.angle))),
                                    (int)(m1.speed * Math.cos(Math.toRadians(m1.angle))), m1.angle);
                            fire.setOwnedBy("m1");
                            clip.add(fire);
                            turret.play();
                            System.out.println("Fire Tank 1");
                        }
                         if (e.getKeyChar() == '\n' && this.equals(m2)) {
                            fire = new Bullet(bullet, m2.x + (m2.width / 2), m2.y + (m2.height / 2),
                                    (int) (m2.speed * Math.sin(Math.toRadians(m2.angle))),
                                    (int) (m2.speed * Math.cos(Math.toRadians(m2.angle))), m2.angle);
                            fire.setOwnedBy("m2");
                            clip.add(fire);
                            turret.play();
                            System.out.println("Fire Tank 2");
                        }
                }
            } else if (ge.type == 2) {
                String msg = (String) ge.event;
                
                if (msg.equals("m1_collision") && this.equals(m1)) {
                    m1.health -= 25;
                    healthBar1.update();
                    if (health > 0) {
                        boom1.play();
                    }
                    System.out.println("Player 1 health: " + m1.health);
                    if (m1.health <= 0) {
                        m1.boom = true;
                        boom2.play();
                    }
                }
                if (msg.equals("m2_collision") && this.equals(m2)) {
                    m2.health -= 25;
                    healthBar2.update();
                            
                    if (health > 0) {
                        boom1.play();
                    }
                    System.out.println("Player 2 health: " + m2.health);
                    if (m2.health <= 0) {
                        m2.boom = true;
                        boom2.play();
                    }
                }
                
            }
        }
    }
    
     public void drawBackGroundWithTileImage() {
      
        int TileWidth = background.getWidth(this);
        int TileHeight = background.getHeight(this);

        int NumberX = (int) (w / TileWidth);
        int NumberY = (int) (h / TileHeight);

        for (int i = -1; i <= NumberY; i++) {
            for (int j = 0; j <= NumberX; j++) {
                g2.drawImage(background, j * TileWidth,
                        i * TileHeight + (move % TileHeight), TileWidth,
                        TileHeight, this);
            }
        }
    }
     
     public void drawDemo() throws IOException, InterruptedException, MalformedURLException, LineUnavailableException, UnsupportedAudioFileException, AWTException {

        drawBackGroundWithTileImage();
    
        for (Wall[] layout1 : layout) {
            for (Wall layout11 : layout1) {
                if (layout11 != null) {
                    layout11.update();
                }
            }
        }
        for(int i=0; i < clip.size(); i++){
            clip.get(i).update(i);
        }
        
       if(explode1 != null && explode1.frameCount < explode1.numFrames){
          explode1.update();
        }
     
        for (Wall[] layout1 : layout) {
            for (Wall layout11 : layout1) {
                if (layout11 != null) {
                    layout11.draw(this);
                }
            }
        }
      
        if(!m1.boom) {
            m1.draw(this);
           }
          
        if(!m2.boom){
           m2.draw(this);
           }
        
        for( Bullet clip1 : clip){
            clip1.draw(this);    
        }
           
        if(m1.boom){
            explode2 = new Explosion("explosion2_", 7, m1.x, m1.y, this);
            m1.y = -100;
           
          }
        
        if(m2.boom){
            explode2 = new Explosion("explosion2_", 7, m2.x, m2.y, this);
            m2.y = -100; 
           
          }
        
        if(explode1 != null && explode1.frameCount < explode1.numFrames){
            explode1.draw(this);
        }
        
        if(explode2 != null && explode2.frameCount < explode2.numFrames){
            explode2.draw(this);    
        }
        
        int x1, y1, x2, y2, width, height;
        x1 = m1.x - 120;
        y1 = m1.y - 300;
        x2 = m2.x - 120;
        y2 = m2.y - 300;
        
        width = 500;
        height = 600;
        
        if(x1 < 0){
            x1 = 0;
        }
        if(x2 < 0){
            x2 = 0;
        }
        if(y1 < 0){
            y1 = 0;
        }
        if(y2 < 0){
            y2 = 0;
        }
        if(x1 + width > 1240) {
            x1 = 735;
        }
        if(x2 + width > 1240){
            x2 = 735;
        }
        if(y1 + height > 692){
            y1 = 86;
        }
        if(y2 + height > 692){
            y2 = 86;
        }
        
        leftScreen = bimg1.getSubimage(x1, y1, width, height);
        rightScreen = bimg1.getSubimage(x2, y2, width, height);
        
        leftScreen = leftScreen.getScaledInstance(800, 950, Image.SCALE_FAST);
        rightScreen = rightScreen.getScaledInstance(800, 950, Image.SCALE_FAST);
        miniMap = bimg1.getScaledInstance(300, 200, Image.SCALE_FAST);
        
        BufferedImage display = new BufferedImage(this.w, this.h, BufferedImage.TYPE_INT_RGB);
        Graphics temp = display.getGraphics();
        
        temp.drawImage(leftScreen, 0, 0, null);
        temp.drawImage(rightScreen, 800, 0, null);
        temp.drawImage(miniMap, 300, 0, null);
        
        g2.drawImage(leftScreen, 0, 0, this);
        g2.drawImage(rightScreen, 640, 0, this);
        g2.drawImage(miniMap, 480, 0, this);
        
        healthBar1.draw(this, 18, 15);
        healthBar2.draw(this, 1200, 15);
        healthLabel1.draw(this, 100, 15);
        healthLabel2.draw(this, 1135, 15); 
        //scoreLabel1.draw(this, 175, 15);
        //scoreLabel2.draw(this, 1000, 15);
        
        
        if(m1.boom || m2.boom){
            m1.boom = true;
            m2.boom = true;
           
            game_over.draw(this, 470, 220);
            gameOver.play();
            g2.setFont(new Font("Impact", Font.BOLD, 30));
            g2.setColor(Color.WHITE);
            g2.drawString("FINAL SCORE", 570, 345);
            g2.setFont(new Font("Impact", Font.BOLD, 25));
            g2.drawString("Player 1", 570, 370);
            g2.drawString(Integer.toString(score1), 702, 370);
            g2.drawString("Player 2", 570, 400);
            g2.drawString(Integer.toString(score2), 685, 400);
        }

    }
     
public void paint(Graphics g) {
        if (bimg1 == null) {
            Dimension windowSize = getSize();
            bimg1 = (BufferedImage) createImage(windowSize.width,
                    windowSize.height);
            g2 = bimg1.createGraphics();

        }
        try {
            drawDemo();
             g.drawImage(bimg1, 0, 0, this);
        } catch (IOException | InterruptedException | LineUnavailableException | UnsupportedAudioFileException | AWTException ex) {
            Logger.getLogger(TankWorld.class.getName()).log(Level.SEVERE, null, ex);
        }
       // g.drawImage(bimg1, 0, 0, this);
    }

     public void start() {
        thread = new Thread(this);
        thread.setPriority(Thread.MIN_PRIORITY);
        thread.start();

    }
     
    public void run() {
        
         Thread me = Thread.currentThread();
         while (thread == me) {
             this.requestFocusInWindow();
             repaint(); 
             
             try{
                 thread.sleep(25);
             } catch(InterruptedException e){
                 break; 
             }
         }
     }
    
     
   public static void main(String argv[]) {
	    final TankWorld game = new TankWorld();
             
            JFrame f = new JFrame("BATTLE GROUNDS");
	    f.addWindowListener(new WindowAdapter() {
        });
            game.init();
	    f.getContentPane().add("Center", game);
	    f.pack();
	    f.setSize(new Dimension(1280, 758)); 
	    f.setVisible(true);
	    f.setResizable(false);
	    f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
	    game.start();
	}
 
}
